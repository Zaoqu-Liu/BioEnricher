#' @title Baidu translation
#' @description Perform Baidu translation.
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param sentence A sentence or word need to be translated.
#' @param from Input language type.
#' @param to Output language type.
#' @param appid User app id from baidu translation api. https://fanyi-api.baidu.com/manage/developer.
#' @param key User Key from baidu translation api. https://fanyi-api.baidu.com/manage/developer.
#' @import openssl
#' @export
#' @examples
#' lzq_translate("BioEnricher is a simple and useful package!")
lzq_translate <- function(sentence,
                          from = "en",
                          to = "zh",
                          appid = "20231122001888718",
                          key = "5GpDqe8F3pmXfnOkEKGQ") {
  seed <- sample(seq_len(100000), 1)
  sign <- paste0(appid, sentence, seed, key)
  sign <- openssl::md5(sign)

  res <- NULL
  repeat {
    url <- httr::modify_url("http://api.fanyi.baidu.com/api/trans/vip/translate",
      query = list(
        q = sentence,
        from = from,
        to = to,
        appid = appid,
        salt = seed,
        sign = sign
      )
    )
    url <- url(url, encoding = "utf-8")
    res <- jsonlite::fromJSON(url)$trans_result[1, 2]
    if (!is.null(res)) {
      break
    }
  }
  return(res)
}
