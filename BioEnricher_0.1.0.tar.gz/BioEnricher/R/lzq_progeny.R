#' @title Perform PROGENy analysis
#' @description Perform PROGENy analysis.
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param exp A gene expression object with HGNC/MGI symbols in rows and samples in columns. In order to run PROGENy in single-cell RNAseq data, it also accepts Seurat and SingleCellExperiment object, taking the normalized counts for the computation.
#' @param scale A logical value indicating whether to scale the scores of each pathway to have a mean of zero and a standard deviation of one. It does not apply if we use permutations.
#' @param organism The model organism - "Human" or "Mouse".
#' @param top The top n genes for generating the model matrix according to significance (p-value).
#' @param perm An interger detailing the number of permutations. No permutations by default (1). When Permutations larger than 1, we compute progeny pathway scores and assesses their significance using a gene sampling-based permutation strategy, for a series of experimental samples/contrasts.
#' @param z_scores Only applies if the number of permutations is greater than 1. A logical value. TRUE: the z-scores will be returned for the pathway activity estimations. FALSE: the function returns a normalized z-score value between -1 and 1.
#' @param get_nulldist Only applies if the number of permutations is greater than 1. A logical value. TRUE: the null distributions generated to assess the signifance of the pathways scores is also returned.
#' @param assay_name Only applies if the input is a Seurat object. It selects the name of the assay on which Progeny will be run. Default to: RNA, i.e. normalized expression values.
#' @param return_assay Only applies if the input is a Seurat object. A logical value indicating whether to return progeny results as a new assay called Progeny in the Seurat object used as input. Default to FALSE.
#' @import progeny
#' @export
#' @examples
#' gene_expression <- as.matrix(read.csv(system.file("extdata", "human_input.csv", package = "progeny"), row.names = 1))
#' s <- lzq_progeny(gene_expression)
lzq_progeny <- function(
    exp,
    scale = T,
    organism = "Human",
    top = 100,
    perm = 1,
    z_scores = F,
    get_nulldist = F,
    assay_name = "RNA",
    return_assay = F) {
  pathways <- progeny::progeny(
    expr = exp,
    scale = scale,
    organism = organism,
    top = top,
    verbose = F,
    z_scores = z_scores,
    get_nulldist = get_nulldist,
    perm = perm,
    assay_name = assay_name,
    return_assay = return_assay
  )
  return(pathways)
}

#' @title Generate the differential expression and PROGENy weight of genes.
#' @description Generate the differential expression and PROGENy weight of genes.
#' @param dea.table A dataframe with two columns, the first is gene id and the second is logFC/-logP/Stat.
#' @param pathway Specific a pathway, such as Androgen, EGFR, Estrogen, Hypoxia, JAK-STAT, MAPK, NFkB, p53, PI3K, TGFb, TNFa, Trail, VEGF, and WNT.
#' @param organism The model organism - "Human" or "Mouse".
#' @param top The top n genes for generating the model matrix according to significance (p-value).
#' @param y.lab Y label for scatter.
#' @param colors Colors for different types of points.
#' @param point.size Size of point.
#' @param label.size Size of gene label.
#' @param theme.plot ggtheme of plot.
#' @import progeny
#' @import ggplot2
#' @import dplyr
#' @import magrittr
#' @export
#' @examples
#' gene_expression <- as.matrix(read.csv(system.file("extdata", "human_input.csv", package = "progeny"), row.names = 1))
#' s <- lzq_progeny(gene_expression)
#'
lzq_progeny.gene.details <- function(
    dea.table,
    pathway,
    organism = "Human",
    top = 100,
    y.lab = bquote(~ Log[2] ~ "(Fold change)"),
    colors = c("#3E94B5", "grey70", "#ED6355"),
    point.size = 2,
    label.size = 4,
    theme.plot = theme_classic(base_line_size = 0.8)) {
  colnames(dea.table) <- c("Gene", "Stat")

  if (organism == "Human") {
    model <- progeny::model_human_full
  }
  if (organism == "Mouse") {
    model <- progeny::model_mouse_full
  }

  model %<>%
    dplyr::group_by(pathway) %>%
    dplyr::slice_min(order_by = p.value, n = top)
  model <- model[model$pathway == pathway, ]
  model2 <- merge(model, dea.table, by = 1) %>%
    dplyr::mutate(color = "A") %>%
    dplyr::mutate(color = ifelse(weight > 0 & Stat > 0, "C", color)) %>%
    dplyr::mutate(color = ifelse(weight > 0 & Stat <= 0, "B", color)) %>%
    dplyr::mutate(color = ifelse(weight <= 0 & Stat > 0, "B", color)) %>%
    dplyr::mutate(color = ifelse(weight <= 0 & Stat <= 0, "A", color))
  model2$Gene2 <- ifelse(model2$color %in% c("A", "C"), as.character(model2$gene), NA)

  p <- suppressWarnings(ggplot(model2, aes(x = weight, y = Stat, color = color)) +
    geom_vline(xintercept = 0, lty = 2, col = "grey70", lwd = 0.65) +
    geom_hline(yintercept = 0, lty = 2, col = "grey70", lwd = 0.65) +
    geom_point(size = point.size) +
    labs(x = "Weight (PROGENy)", y = y.lab, title = pathway) +
    theme.plot +
    scale_colour_manual(values = colors) +
    ggrepel::geom_label_repel(
      mapping = aes(label = Gene2),
      size = label.size,
      box.padding = unit(0.35, "lines"),
      point.padding = unit(0.3, "lines"),
      max.overlaps = 20
    ) +
    theme(
      axis.text = element_text(size = 10, colour = "black"),
      axis.title.x = element_text(size = 13, colour = "black", face = "bold"),
      axis.title.y = element_text(size = 13, colour = "black", face = "bold"),
      panel.grid = element_blank(),
      panel.background = element_rect(fill = "white"),
      plot.title = element_text(hjust = 0.5, size = 14, colour = "black", face = "bold"),
      legend.position = "none"
    ))
  print(suppressWarnings(p))
  return(list(res = model2[, seq_len(5)], plot = p))
}

#' @title Perform differential analysis for the PROGENy results.
#' @description Perform differential analysis for the PROGENy results.
#' @param progeny.res A PROGENy results with row samples and column pathways.
#' @param groups Group information that matches the row sample names.
#' @param control.group Specify the control group.
#' @param theme.plot ggtheme of plot.
#' @export
#' @examples
#' gene_expression <- as.matrix(read.csv(system.file("extdata", "human_input.csv", package = "progeny"),
#'   row.names = 1
#' ))
#' s <- lzq_progeny(gene_expression)
#' l <- lzq_progeny.dea(s, groups = rep(c("A", "B"), each = 4), "A")
lzq_progeny.dea <- function(
    progeny.res,
    groups,
    control.group,
    theme.plot = theme_classic(base_line_size = 0.8)) {
  groups <- ifelse(groups == control.group, T, F)

  result <- apply(progeny.res, 2, function(x) {
    broom::tidy(stats::lm(x ~ !groups)) %>%
      filter(term == "!groupsTRUE") %>%
      dplyr::select(-term)
  }) %>%
    Reduce(rbind, .)
  result <- cbind(pathways = colnames(progeny.res), result)

  t_value <- stats::qt(1 - 0.05 / 2, nrow(progeny.res) - 2)

  p <- ggplot(result, aes(y = stats::reorder(pathways, statistic), x = statistic)) +
    geom_vline(xintercept = t_value, lty = 2, col = "grey70", lwd = 0.65) +
    geom_vline(xintercept = -t_value, lty = 2, col = "grey70", lwd = 0.65) +
    geom_segment(aes(
      x = 0, xend = statistic, y = stats::reorder(pathways, statistic),
      yend = stats::reorder(pathways, statistic)
    ), color = "grey80", size = 0.8) +
    geom_point(aes(color = pathways, size = -log10(p.value))) +
    theme_bw() +
    labs(x = "Statistic", y = NULL) +
    scale_color_manual(values = paletteer::paletteer_d("ggsci::category20_d3", n = 14)) +
    scale_size(range = c(2, 6)) +
    theme.plot +
    theme(
      axis.text.x = element_text(size = 10, colour = "black"),
      axis.title.x = element_text(size = 13, colour = "black", face = "bold"),
      axis.text.y = element_text(size = 12, colour = "black"),
      panel.grid = element_blank(),
      panel.background = element_rect(fill = "white"),
      plot.title = element_text(hjust = 0.5, size = 14, colour = "black", face = "bold"),
      legend.position = "none"
    )
  print(p)
  return(list(res = result, plot = p))
}
utils::globalVariables(c("term", ".", "pathways", "statistic", "pvalue"))
