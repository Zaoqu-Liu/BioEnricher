## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(BioEnricher)
data("crc.data") # A list including expression and group data from a part of TCGA-CRC.
exp <- crc.data$exp
group <- crc.data$group

## -----------------------------------------------------------------------------
pca <- lzq_PCAplot(
  expr = exp,
  scale = T,
  Group = group,
  levels = c("Normal", "Tumor"),
  cols = c("#3E94B5", "#ED6355")
)

## -----------------------------------------------------------------------------
dea <- lzq_limma_DEA(
  expr = exp,
  group = group,
  contrasts = "Tumor-Normal",
  Select_P = "FDR",
  cutoff_logFC = 1,
  cutoff_P = 0.05
)

## ----fig.height=4.5, fig.width=4----------------------------------------------
lzq_volcano(
  DEG = dea,
  logFC_Ncol = 2,
  Select_P = "FDR",
  P_Ncol = 6,
  DEG_type_Ncol = 8,
  cutoff_P = 0.05,
  cutoff_logFC = 1,
  cols = c("#3E94B5", "#E3E3E3", "#ED6355"),
  Select_genes = c("ETV4", "CDH3", "SLC26A3", "MYH11")
)

## -----------------------------------------------------------------------------
# Define an up-regulated gene list
up.genes <- dea$Gene[dea$Type == "Up"]
# Define a down-regulated gene list
down.genes <- dea$Gene[dea$Type == "Down"]

listEnrichMethod()

# This function will perform over-representative analysis including GO, KEGG,
# WikiPathways, Reactome, MsigDB, Disease Ontoloty, Cancer Gene Network,
# DisGeNET, CellMarker, and CMAP.

# Set enrich.type using an enrichment analysis method mentioned above.
up.go <- lzq_ORA(
  genes = up.genes,
  enrich.type = "GO"
)
down.go <- lzq_ORA(
  genes = down.genes,
  enrich.type = "GO"
)

## ----fig.height=4, fig.width=7------------------------------------------------
lzq_ORA.barplot1(enrich.obj = up.go$simplyGO)

lzq_ORA.dotplot1(enrich.obj = up.go$simplyGO)

## ----fig.height=5.5-----------------------------------------------------------
lzq_ORA.barplot2(
  enrich.obj1 = up.go$simplyGO,
  enrich.obj2 = down.go$simplyGO,
  obj.types = c("Up", "Down")
)

## -----------------------------------------------------------------------------
# Obtain an order ranked geneList.
grlist <- dea$logFC
names(grlist) <- dea$Gene
grlist <- sort(grlist, decreasing = T)

listEnrichMethod()

## -----------------------------------------------------------------------------
# Set enrich.type using an enrichment analysis method mentioned above.
fit <- lzq_GSEA(grlist, enrich.type = "Reactome")

## -----------------------------------------------------------------------------
lzq_gseaplot(
  GSEA.result = fit,
  Pathway.ID = "R-HSA-1640170",
  rank = F,
  statistic.position = c(0.71, 0.85),
  rel.heights = c(1, 0.4)
)

## ----fig.height=4, fig.width=8.3----------------------------------------------
lzq_GSEA.barplot1(enrich.obj = fit, type = "pos")

lzq_GSEA.dotplot1(enrich.obj = fit, type = "pos")

## ----fig.height=5.5-----------------------------------------------------------
lzq_GSEA.barplot2(enrich.obj = fit)

## -----------------------------------------------------------------------------
ps <- lzq_progeny(exp = as.matrix(exp), top = 100)

## ----fig.height=4, fig.width=5------------------------------------------------
ps_dea <- lzq_progeny.dea(
  progeny.res = ps,
  groups = group,
  control.group = "Normal"
)

## ----fig.height=5.5, fig.width=5.5--------------------------------------------
ps_wnt <- lzq_progeny.gene.details(
  dea.table = dea[, seq_len(2)],
  pathway = "WNT"
)

## -----------------------------------------------------------------------------
tf <- lzq_inferTF(
  exp = as.matrix(exp),
  use.cancer.regulons = T
)

## ----fig.height=4.5, fig.width=4----------------------------------------------
tf.dea <- lzq_score.matrix.dea(
  score.matrix = tf,
  groups = group,
  control.group = "Normal",
  Select.P = "FDR",
  cutoff.P = 0.05,
  cutoff.logFC = 2,
  Select_genes = c("E2F4", "IRF3", "TEAD1", "IRF4")
)

## -----------------------------------------------------------------------------
head(lzq_tf.details(tf.genes = c("E2F4", "IRF3"), confidences = "A"))

## -----------------------------------------------------------------------------
lzq_tf.details(targets = c("KLK10", "BMP4"), confidences = "A")

## -----------------------------------------------------------------------------
lzq_tf.details(tf.genes = "MYC", targets = c("BMP4", "KLK10"), confidences = "A")

## -----------------------------------------------------------------------------
sessionInfo()

