#' @title Get numeric GeneRatio and BgRatio from enrichResult
#' @description Get numeric GeneRatio and BgRatio from enrichResult (clusterProfiler).
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param res enrichResult from clusterProfiler.
#' @return A new result with numeric GeneRatio and BgRatio.
#' @export
#' @examples
#' genes <- c("CANX", "HSPA1B", "KLRC2", "PSMC6", "RFXAP", "TAP1")
#' obj <- clusterProfiler::enrichGO(genes, org.Hs.eg.db::org.Hs.eg.db,
#'   keyType = "SYMBOL", ont = "BP"
#' )
#' obj2 <- BioEnricher::lzq_getGR_BR(obj)
#' obj2@result$GeneRatio
#' obj2@result$BgRatio
lzq_getGR_BR <- function(res) {
  res@result$GeneRatio <- apply(res@result, 1, function(x) {
    eval(parse(text = x["GeneRatio"]))
  })
  res@result$BgRatio <- apply(res@result, 1, function(x) {
    eval(parse(text = x["BgRatio"]))
  })
  return(res)
}
