#' @title Perform differential analysis for the score matrix
#' @description Perform differential analysis for the score matrix.
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param score.matrix A score matrix.
#' @param groups Group information that matches the score matrix column sample names.
#' @param control.group Specify the control group.
#' @param Select.P Nominal P value (NP) or adjust P value (FDR) were selected to define differential terms.
#' @param cutoff.P A cutoff value for Select.P.
#' @param cutoff.logFC An absolute value of logFC for defining differential terms.
#' @param ... Additional parameters will be passed to the lzq_limma_DEA().
#' @return A list consisted of DEA results and volcano plots.
#' @export
lzq_score.matrix.dea <- function(
    score.matrix,
    groups,
    control.group,
    Select.P = "FDR",
    cutoff.P = 0.05,
    cutoff.logFC = 2,
    ...) {
  groups <- ifelse(groups == control.group, "A", "B")

  res <- lzq_limma_DEA(score.matrix, groups,
    contrasts = "B-A",
    Select_P = Select.P,
    cutoff_P = cutoff.P,
    cutoff_logFC = cutoff.logFC
  )
  p <- lzq_volcano(res,
    Select_P = Select.P,
    cutoff_P = cutoff.P,
    cutoff_logFC = cutoff.logFC,
    ...
  )
  print(p)
  return(list(res = res, plot = p))
}
