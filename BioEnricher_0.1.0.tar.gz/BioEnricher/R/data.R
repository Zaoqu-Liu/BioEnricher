#' A vector of colors
#' @format A vector with 11 types of colors.
#'
"cols_brown_green"

#' A dataframe including drugs and their related genes
#' @format A dataframe with four columns from DSEATM
#'
"CMAPfromDSEATM"

#' A list including expression and group data from a part of TCGA-CRC.
#' @format A list with two elements
#'
"crc.data"
