#' @title KEGG pathway visualization
#' @description Simple visualization of KEGG pathway based on pathview package.
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param gene.data either vector (single sample) or a matrix-like data (multiple sample). Vector should be numeric with gene IDs as names or it may also be character of gene IDs. Character vector is treated as discrete or count data. Matrix-like data structure has genes as rows and samples as columns. Row names should be gene IDs. Here gene ID is a generic concepts, including multiple types of gene, transcript and protein uniquely mappable to KEGG gene IDs. KEGG ortholog IDs are also treated as gene IDs as to handle metagenomic data. Check details for mappable ID types. Default gene.data=NULL.
#' @param gene.type character, ID type used for the gene.data, case insensitive. Default gene.idtype="entrez", i.e. Entrez Gene, which are the primary KEGG gene ID for many common model organisms. For other species, gene.idtype should be set to "KEGG" as KEGG use other types of gene IDs. For the common model organisms (to check the list, do: data(bods); bods), you may also specify other types of valid IDs. To check the ID list, do: data(gene.idtype.list); gene.idtype.list.
#' @param pathway.id character vector, the KEGG pathway ID(s), usually 5 digit, may also include the 3 letter KEGG species code.
#' @param species character, either the kegg code, scientific name or the common name of the target species. This applies to both pathway and gene.data or cpd.data. When KEGG ortholog pathway is considered, species="ko". Default species="hsa", it is equivalent to use either "Homo sapiens" (scientific name) or "human" (common name).
#' @param figure.suffix character, the suffix to be added after the pathway name as part of the output graph file. Sample names or column names of the gene.data or cpd.data are also added when there are multiple samples. Default out.suffix="pathview".
#' @import pathview
#' @export
#' @examples
#' library(airway)
#' library(DESeq2)
#' library(tidyverse)
#' library(clusterProfiler)
#' library(org.Hs.eg.db)
#' data(airway)
#' se <- airway
#' se$dex <- relevel(se$dex, "untrt")
#' res <- DESeqDataSet(se, design = ~ cell + dex) %>%
#'   estimateSizeFactors() %>%
#'   DESeq() %>%
#'   results() %>%
#'   as.data.frame() %>%
#'   na.omit()
#' ann <- bitr(rownames(res), "ENSEMBL", "SYMBOL", org.Hs.eg.db)
#' res <- merge(ann, res, by.x = 1, by.y = 0) %>% dplyr::distinct(SYMBOL, .keep_all = TRUE)
#'
#' # Set enrich.type using an enrichment analysis method mentioned above.
#' kegg <- lzq_ORA(
#'   genes = res$SYMBOL[res$log2FoldChange > 0 & res$padj < 0.05],
#'   enrich.type = "KEGG"
#' )
#'
#' res2 <- res[res$log2FoldChange > 0 & res$padj < 0.05, c(2, 4)]
#' res2 <- data.frame(row.names = res2$SYMBOL, R = res2$log2FoldChange)
#'
#' lzq_KEGGview(gene.data = res2, pathway.id = "hsa04218")
lzq_KEGGview <- function(
    gene.data = NULL,
    gene.type = "SYMBOL",
    pathway.id,
    species = "hsa",
    figure.suffix = "") {
  pathview::pathview(
    gene.data = gene.data,
    gene.idtype = gene.type,
    pathway.id = gsub("\\D", "", pathway.id),
    species = species,
    kegg.native = T,
    out.suffix = figure.suffix,
    low = list(gene = "#0a9396", cpd = "blue"),
    mid = list(gene = "#e9d8a6", cpd = "gray"),
    high = list(gene = "#bb3e03", cpd = "yellow"),
  )

  imgpng <- png::readPNG(paste0(pathway.id, ".", figure.suffix, ".png"))
  graphics::par(mar = c(0, 0, 0, 0))
  graphics::plot.new()
  graphics::rasterImage(imgpng, 0, 0, 1, nrow(imgpng) / ncol(imgpng))
}
