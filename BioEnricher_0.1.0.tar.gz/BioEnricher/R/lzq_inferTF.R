#' @title Perform VIPER analysis
#' @description This function performs Virtual Inference of Protein-activity by Enriched Regulon analysis
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param exp Numeric matrix containing the expression data or gene expression signatures, with samples in columns and genes in rows.
#' @param organism Specify species, currently support only Human and Mouse.
#' @param use.cancer.regulons Use TF-target interactions for cancer application.
#' @param confidences The score comprises five categories, ranging from A (highest confidence) to E (lowest confidence). The scoring criteria are described in PMID: 31340985.
#' @return A matrix of inferred activity for each regulator gene in the network across all samples.
#' @import dorothea
#' @export
#' @examples
#' gene_expression <- as.matrix(read.csv(system.file("extdata", "human_input.csv", package = "progeny"),
#'   row.names = 1
#' ))
#' s <- lzq_inferTF(gene_expression)
lzq_inferTF <- function(
    exp,
    organism = "Human",
    use.cancer.regulons = F,
    confidences = c("A", "B", "C")) {
  if (organism == "Human") {
    if (use.cancer.regulons) {
      regulons <- dorothea::dorothea_hs
    } else {
      regulons <- dorothea::dorothea_hs_pancancer
    }
  }
  if (organism == "Mouse") {
    if (use.cancer.regulons) {
      regulons <- dorothea::dorothea_mm
    } else {
      regulons <- dorothea::dorothea_mm_pancancer
    }
  }

  regulons <- regulons %>%
    dplyr::filter(confidence %in% confidences)
  tf_activities <- suppressWarnings(dorothea::run_viper(
    input = exp,
    regulons = regulons,
    options = list(
      method = "scale",
      minsize = 4,
      eset.filter = F,
      cores = 1,
      verbose = F
    )
  )) %>%
    as.data.frame()
  return(tf_activities)
}

#' @title Extract the details of specific TF genes from regulons
#' @description Extract the details of specific TF genes from regulons.
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param tf.genes specific TF genes.
#' @param targets Targets genes are regulated by TFs.
#' @param organism Specify species, currently support only Human and Mouse.
#' @param use.cancer.regulons Use TF-target interactions for cancer application.
#' @param confidences The score comprises five categories, ranging from A (highest confidence) to E (lowest confidence). The scoring criteria are described in PMID: 31340985.
#' @return A matrix with the details of tf and its targets.
#' @import dorothea
#' @export
#' @examples
#' lzq_tf.details("ATF3")
lzq_tf.details <- function(
    tf.genes = NULL,
    targets = NULL,
    organism = "Human",
    use.cancer.regulons = F,
    confidences = c("A", "B", "C")) {
  if (organism == "Human") {
    if (use.cancer.regulons) {
      regulons <- dorothea::dorothea_hs
    } else {
      regulons <- dorothea::dorothea_hs_pancancer
    }
  }
  if (organism == "Mouse") {
    if (use.cancer.regulons) {
      regulons <- dorothea::dorothea_mm
    } else {
      regulons <- dorothea::dorothea_mm_pancancer
    }
  }

  regulons <- regulons %>%
    dplyr::filter(confidence %in% confidences)

  if (is.null(tf.genes)) {
    if (is.null(targets)) {
      stop("You must specify one or multiple TFs or targets!")
    }
    res <- as.data.frame(regulons[regulons$target %in% targets, ])
  }

  if (is.null(targets)) {
    if (is.null(tf.genes)) {
      stop("You must specify one or multiple TFs or targets!")
    }
    res <- as.data.frame(regulons[regulons$tf %in% tf.genes, ])
  }

  if (!is.null(targets) & !is.null(tf.genes)) {
    res <- as.data.frame(regulons[regulons$tf %in% tf.genes, ])
    res <- res[res$target %in% targets, ]
  }

  return(res)
}
