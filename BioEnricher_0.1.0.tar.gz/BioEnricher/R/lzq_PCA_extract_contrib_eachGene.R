#' @title Extract the contribution of each gene from PC1.
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param expr A dataframe of matrix with sample columns and feature rows.
#' @param scale A Boolean value. Whether to perfrom scale the matrix based on the features.
#' @param axes A numeric vector specifying the dimension(s) of interest.
#' @export
lzq_PCA_extract_contrib_eachGene <- function(expr, scale = T, axes = 1) {
  # axes: a numeric vector specifying the dimension(s) of interest.

  if (scale) {
    expr <- t(scale(t(expr)))
  }
  pca <- FactoMineR::PCA(expr, graph = F)
  k <- factoextra::fviz_contrib(pca, choice = "ind", axes = 1)
  d <- k$data
  d <- d[order(d$contrib, decreasing = T), ]
  d2 <- d$contrib
  names(d2) <- d$name
  return(d2)
}
