#' @title Perform differential expression analysis with limma voom.
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param counts A RNA-seq count matrix or dataframe with sample columns and gene rows.
#' @param group Group information that matches the counts column sample names.
#' @param contrasts Of the two groups, who will be compared to whom.
#' @param Select_P Nominal P value (NP) or adjust P value (FDR) were selected to define differential genes.
#' @param cutoff_P A cutoff value for Select_P.
#' @param cutoff_logFC An absolute value of logFC for defining differential genes.
#' @export
lzq_limma_DEA_voom <- function(counts, group, contrasts = "Tumor-Normal", Select_P = c("NP", "FDR"), cutoff_P, cutoff_logFC) {
  k <- strsplit(contrasts, "-")[[1]]
  group <- ifelse(group == k[1], "V1", "V2")
  design <- stats::model.matrix(~ 0 + factor(group))
  colnames(design) <- levels(factor(group))
  rownames(design) <- colnames(counts)
  norm <- limma::voom(counts, design)
  fit <- limma::lmFit(norm, design, method = "ls")
  contrast <- limma::makeContrasts(V1 - V2, levels = design)
  fit2 <- limma::contrasts.fit(fit, contrast)
  fit2 <- limma::eBayes(fit2) # 用经验贝叶斯调整t-test中方差的部分
  DEG <- limma::topTable(fit2, coef = 1, number = Inf, sort.by = "logFC", adjust.method = "fdr")
  DEG <- tibble::rownames_to_column(DEG, "Gene")
  if (Select_P == "NP") {
    DEG$Type <- ifelse(DEG$P.Value >= cutoff_P, "NoSig", ifelse(DEG$logFC > cutoff_logFC, "Up", ifelse(DEG$logFC < -cutoff_logFC, "Down", "NoSig")))
  }
  if (Select_P == "FDR") {
    DEG$Type <- ifelse(DEG$adj.P.Val >= cutoff_P, "NoSig", ifelse(DEG$logFC > cutoff_logFC, "Up", ifelse(DEG$logFC < -cutoff_logFC, "Down", "NoSig")))
  }
  print(table(DEG$Type))
  return(DEG)
}

#' @title Perform differential expression analysis with limma.
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param expr A expression matrix or dataframe with sample columns and gene rows.
#' @param group Group information that matches the counts column sample names.
#' @param contrasts Of the two groups, who will be compared to whom.
#' @param Select_P Nominal P value (NP) or adjust P value (FDR) were selected to define differential genes.
#' @param cutoff_P A cutoff value for Select_P.
#' @param cutoff_logFC An absolute value of logFC for defining differential genes.
#' @export
lzq_limma_DEA <- function(expr, group, contrasts = "Tumor-Normal", Select_P = c("NP", "FDR"), cutoff_P, cutoff_logFC) {
  k <- strsplit(contrasts, "-")[[1]]
  group <- ifelse(group == k[1], "V1", "V2")
  design <- stats::model.matrix(~ 0 + factor(group))
  colnames(design) <- levels(factor(group))
  rownames(design) <- colnames(expr)
  contrast.matrix <- limma::makeContrasts(V1 - V2, levels = design)
  fit <- limma::lmFit(expr, design)
  fit2 <- limma::contrasts.fit(fit, contrast.matrix)
  fit2 <- limma::eBayes(fit2) # 用经验贝叶斯调整t-test中方差的部分
  DEG <- limma::topTable(fit2, coef = 1, number = Inf, sort.by = "logFC", adjust.method = "fdr")
  DEG <- tibble::rownames_to_column(DEG, "Gene")
  if (Select_P == "NP") {
    DEG$Type <- ifelse(DEG$P.Value >= cutoff_P, "NoSig", ifelse(DEG$logFC > cutoff_logFC, "Up", ifelse(DEG$logFC < -cutoff_logFC, "Down", "NoSig")))
  }
  if (Select_P == "FDR") {
    DEG$Type <- ifelse(DEG$adj.P.Val >= cutoff_P, "NoSig", ifelse(DEG$logFC > cutoff_logFC, "Up", ifelse(DEG$logFC < -cutoff_logFC, "Down", "NoSig")))
  }
  print(table(DEG$Type))
  return(DEG)
}
