#' @title Volcano plot
#' @description
#' Draw advanced volcano maps with the option to display personalized genes or not.
#'
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param DEG A dataframe of matrix with at least information of P-value, logFC.
#' @param logFC_Ncol logFC is in which column.
#' @param P_Ncol P-value is in which column.
#' @param Select_P Nominal P value (NP) or adjust P value (FDR) were selected to define differential genes.
#' @param DEG_type_Ncol Classes of differential genes is in which column.
#' @param cutoff_P A cutoff value for Select_P.
#' @param cutoff_logFC An absolute value of logFC for defining differential genes.
#' @param cols Three colors for classes of differential genes.
#' @param col_levels Corresponding to the classes of differential genes for the three colors.
#' @param point_maxsize Max size of points.
#' @param point_alpha Color alpha of points.
#' @param rect_size Size of axis rect.
#' @param intercept_lwd Width of intercept lines.
#' @param Gene_Ncol Gene is in which column.
#' @param Select_genes A vector of genes will be displayed.
#' @param label_size Size of gene labels.
#' @param legend_position The legend position. right, left, top, bottom.
#' @export
lzq_volcano <- function(DEG,
                        logFC_Ncol = 2,
                        Select_P = "FDR",
                        P_Ncol = 6,
                        DEG_type_Ncol = 8,
                        cutoff_P = 0.05,
                        cutoff_logFC = 1,
                        cols = c("#3E94B5", "#E3E3E3", "#ED6355"),
                        col_levels = c("Down", "NoSig", "Up"),
                        point_maxsize = 4,
                        point_alpha = 0.8,
                        rect_size = 1.5,
                        intercept_lwd = 0.65,
                        Gene_Ncol = 1,
                        Select_genes = NULL,
                        label_size = 4,
                        legend_position = "bottom") {
  tmp <- DEG
  colnames(tmp)[c(logFC_Ncol, P_Ncol, DEG_type_Ncol)] <- c("logFC", "P", "Type")
  tmp$Type <- factor(tmp$Type, levels = col_levels)
  if (!is.null(Select_genes)) {
    colnames(tmp)[Gene_Ncol] <- "Gene"
    tmp$Select_label <- ifelse(tmp$Gene %in% Select_genes, tmp$Gene, NA)
    tmp2 <- tmp[stats::complete.cases(tmp$Select_label), ]
  }

  p1 <- ggplot2::ggplot(tmp, aes(logFC, -log10(P))) +
    ggplot2::geom_point(alpha = point_alpha, aes(color = Type, size = abs(logFC))) +
    ggplot2::geom_vline(xintercept = c(-cutoff_logFC, cutoff_logFC), lty = 2, col = "grey20", lwd = intercept_lwd) +
    ggplot2::geom_hline(yintercept = -log10(cutoff_P), lty = 2, col = "grey20", lwd = intercept_lwd) +
    ggplot2::scale_color_manual(values = cols) +
    ggplot2::scale_size_area(max_size = point_maxsize) +
    ggplot2::theme_bw(base_rect_size = rect_size) +
    ggplot2::labs(
      x = bquote(~ Log[2] ~ "(Fold change)"),
      y = switch(Select_P,
        NP = bquote(~ -Log[10] ~ italic("P-value")),
        FDR = bquote(~ -Log[10] ~ "FDR")
      )
    ) +
    ggplot2::xlim(-max(abs(tmp$logFC)) * 1.05, max(abs(tmp$logFC)) * 1.05) +
    ggplot2::theme(
      axis.text = element_text(size = 10, colour = "black"),
      axis.title.x = element_text(size = 13, colour = "black", face = "bold"),
      axis.title.y = element_text(size = 13, colour = "black", face = "bold"),
      panel.grid = element_blank(),
      panel.background = element_rect(fill = "white"),
      plot.title = element_text(hjust = 0.5, size = 14, colour = "black", face = "bold"),
      legend.position = legend_position,
      legend.background = element_blank(),
      legend.key = element_blank(),
      legend.title = element_blank(),
      legend.text = element_text(size = 13, colour = "black")
    ) +
    ggplot2::guides(size = "none", color = guide_legend(order = 0, override.aes = list(size = point_maxsize, alpha = 1)))

  if (!is.null(Select_genes)) {
    p2 <- p1 + ggplot2::geom_point(data = tmp2, alpha = 1, size = point_maxsize, shape = 1, stroke = 1, color = "black") +
      ggrepel::geom_text_repel(
        data = tmp2, mapping = aes(label = Select_label),
        size = label_size,
        box.padding = unit(0.35, "lines"),
        point.padding = unit(0.3, "lines"),
        max.overlaps = 20
      )
  }

  if (!is.null(Select_genes)) {
    return(list(volcano = p1, Volcano_with_labels = p2))
  } else {
    return(p1)
  }
}
