#' @title Get enrichment factor from enrichResult
#' @description Get enrichment factor from enrichResult (clusterProfiler).
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param res enrichResult from clusterProfiler.
#' @return A new result with enrichment factor.
#' @export
#' @examples
#' genes <- c("CANX", "HSPA1B", "KLRC2", "PSMC6", "RFXAP", "TAP1")
#' obj <- clusterProfiler::enrichGO(genes, org.Hs.eg.db::org.Hs.eg.db,
#'   keyType = "SYMBOL", ont = "BP"
#' )
#' obj2 <- BioEnricher::lzq_getEF(obj)
#' obj2@result$EnrichmentFactor
lzq_getEF <- function(res) {
  res@result$EnrichmentFactor <- apply(res@result, 1, function(x) {
    GeneRatio <- eval(parse(text = x["GeneRatio"]))
    BgRatio <- eval(parse(text = x["BgRatio"]))
    EF <- round(GeneRatio / BgRatio, 2)
  })
  return(res)
}
