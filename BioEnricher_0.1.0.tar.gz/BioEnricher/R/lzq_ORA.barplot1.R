#' @title Enrichment barplot for one ORA enrichment object
#' @description Plot enrichment barplot for one ORA enrichment object.
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param enrich.obj An object from clusterProfiler.
#' @param x variable for x-axis, one of 'GeneRatio', 'pvalue', 'p.adjust', 'Count', EnrichmentFactor.
#' @param show.term.num A number or a list of terms. If it is a number, the first n terms will be displayed. If it is a list of terms, the selected terms will be displayed.
#' @param color.by variable that used to color enriched terms, one of 'GeneRatio', 'pvalue', 'p.adjust', 'Count', EnrichmentFactor.
#' @param colors A color vector for the bars.
#' @param color.title Title of color annotation legend.
#' @param bar.width Width of bars.
#' @param add.bar.border Logical. Whether to add the black border of bars.
#' @param y.label.position Y label position. right or left.
#' @param title Title of the plot.
#' @param legend.position Position of legend. 'none', 'right', 'left' or two numeric variables.
#' @param theme.plot ggtheme of plot.
#' @param use.Chinese Logical. Whether to use Chinese annotation in the barplot.
#' @param appid User app id from baidu translation api. https://fanyi-api.baidu.com/manage/developer.
#' @param key User Key from baidu translation api. https://fanyi-api.baidu.com/manage/developer.
#' @export
#' @examples
#' genes <- c("CANX", "HSPA1B", "KLRC2", "PSMC6", "RFXAP", "TAP1")
#' res <- lzq_ORA(genes, enrich.type = "GO")
#' lzq_ORA.barplot1(res$simplyGO)
lzq_ORA.barplot1 <- function(
    enrich.obj,
    x = "GeneRatio",
    show.term.num = 15,
    color.by = "p.adjust",
    colors = c(
      "#003c30", "#01665e", "#35978f", "#80cdc1", "#c7eae5", "#f5f5f5",
      "#f6e8c3", "#dfc27d", "#bf812d", "#8c510a", "#543005"
    ),
    color.title = color.by,
    bar.width = 0.6,
    add.bar.border = F,
    y.label.position = "right",
    title = NULL,
    legend.position = "right",
    theme.plot = theme_bw(base_rect_size = 1.5),
    use.Chinese = F,
    appid = "20231122001888718",
    key = "5GpDqe8F3pmXfnOkEKGQ") {
  enrich.obj <- lzq_getGR_BR(enrich.obj)
  x.lab <- x
  if (x == "pvalue") {
    enrich.obj@result$Sig <- -log10(enrich.obj@result$pvalue)
    x.lab <- bquote(~ -Log[10] ~ italic("P-value"))
    x <- "Sig"
  }
  if (x == "p.adjust") {
    enrich.obj@result$Sig <- -log10(enrich.obj@result$p.adjust)
    x.lab <- bquote(~ -Log[10] ~ "FDR")
    x <- "Sig"
  }
  if (x == "EnrichmentFactor") {
    x.lab <- "Enrichment factor"
  }

  if (color.by == "pvalue") {
    enrich.obj@result$SigL <- -log10(enrich.obj@result$pvalue)
    color.title <- bquote(~ -Log[10] ~ italic("P-value"))
    color.by <- "SigL"
  }
  if (color.by == "p.adjust") {
    enrich.obj@result$SigL <- -log10(enrich.obj@result$p.adjust)
    color.title <- bquote(~ -Log[10] ~ "FDR")
    color.by <- "SigL"
  }

  show.term.num <- ifelse(nrow(enrich.obj@result) >= show.term.num, show.term.num, nrow(enrich.obj@result))

  dd <- enrich.obj@result %>%
    dplyr::arrange(pvalue) %>%
    .[seq_len(show.term.num), ] %>%
    dplyr::arrange(desc(get(x)))

  if (use.Chinese) {
    dd$Description <- purrr::map_vec(dd$Description, ~ lzq_translate(.x, appid = appid, key = key))
    dd <- dplyr::mutate(dd, Description = factor(Description, rev(Description)))
    showtext::showtext_auto()
  } else {
    dd <- dplyr::mutate(dd, Description = factor(Description, rev(Description)))
  }

  suppressWarnings(
    ggplot(dd, aes_string(x, "Description", fill = color.by)) +
      geom_bar(stat = "identity", width = bar.width, color = ifelse(add.bar.border, "black", NA)) +
      theme.plot +
      labs(fill = color.title, x = x.lab, y = NULL, title = title) +
      scale_fill_gradientn(colours = colors) +
      scale_y_discrete(
        labels = Hmisc::capitalize,
        position = y.label.position
      ) +
      theme(
        axis.text.x = element_text(size = 10, colour = "black"),
        axis.title.x = element_text(size = 13, colour = "black", face = "bold"),
        axis.text.y = element_text(size = 13, colour = "black"),
        axis.title = element_blank(),
        panel.background = element_blank(),
        legend.text = element_text(size = 11, colour = "black"),
        legend.title = element_text(size = 13, colour = "black", face = "bold"),
        legend.background = element_blank(),
        legend.key = element_blank(),
        legend.position = legend.position,
        plot.title = element_text(hjust = 0.5, size = 14, colour = "black", face = "bold")
      )
  )
}
utils::globalVariables(c("pvalue", ".", "Description"))
