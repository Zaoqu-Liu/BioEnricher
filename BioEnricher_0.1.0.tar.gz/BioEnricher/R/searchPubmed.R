#' @title Get 'PubMed' paper records by searching abstract
#' @description
#' Get 'PubMed' paper records by searching abstract. This function is from europepmc package.
#' @param term query terms e.g. gene id, GO/KEGG pathway
#' @param add_term other searching terms Default is NULL
#' @param num limit the number of records . Default is 100.
#' @importFrom europepmc epmc_search
#' @return A list of dataframe for PubMed records
#' @export
#' @examples
#' term <- c("Tp53", "Brca1", "Tet2")
#' add_term <- c("stem cell", "mouse")
#' l <- searchPubmed(term, add_term, num = 30)
searchPubmed <- function(term, add_term = NULL, num = 100) {
  if (!is.null(add_term)) {
    supp <- paste0("AND ABSTRACT:", add_term) %>% paste(collapse = " ")
  } else {
    supp <- NULL
  }

  res <- lapply(term, function(i) {
    europepmc::epmc_search(
      query = paste0("ABSTRACT:", i, " ", supp),
      limit = num, verbose = F
    ) %>% as.data.frame()
  })
  names(res) <- term
  return(res)
}

#' @title Get the yearly number of hits for a query and the total yearly number of hits for a given period
#' @description
#' Get the yearly number of hits for a query and the total yearly number of hits for a given period. This function is from europepmc package.
#'
#' @param term query terms e.g. gene id, GO/KEGG pathway
#' @param add_term other searching terms Default is NULL
#' @param period a vector of years (numeric) over which to perform the search.
#' @importFrom europepmc epmc_hits_trend
#' @return a data.frame (dplyr tbl_df) with year, total number of hits (all_hits) and number of hits for the query (query_hits).
#' @export
#' @examples
#' term <- c("Tp53", "Brca1", "Tet2")
#' add_term <- c("stem cell", "mouse")
#' l <- searchPubmedTrend(term, add_term, period = 2020:2023)
searchPubmedTrend <- function(term, add_term = NULL, period) {
  if (!is.null(add_term)) {
    supp <- paste0("AND ABSTRACT:", add_term) %>% paste(collapse = " ")
  } else {
    supp <- NULL
  }

  res <- lapply(term, function(i) {
    europepmc::epmc_hits_trend(paste0("ABSTRACT:", i, " ", supp), period = period, synonym = FALSE)
  })
  names(res) <- term

  return(res)
}
