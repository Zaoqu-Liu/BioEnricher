#' @title Enrichment dotplot for positive or negative GSEA results
#' @description Plot enrichment dotplot for positive or negative GSEA results.
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @param enrich.obj A GSEA enrichment object from clusterProfiler.
#' @param type Specify whether you want to show positive or negative results.
#' @param show.term.num A number or a list of terms. If it is a number, the first n terms will be displayed. If it is a list of terms, the selected terms will be displayed.
#' @param Selct.P Nominal P value (NP) or adjust P value (FDR) were selected to define significant terms.
#' @param cutoff.P A cutoff value for Select_P.
#' @param colors A color vector for the bars.
#' @param size.range Two numeric variables, the first is minimal value and the first is maximal value.
#' @param y.label.position Y label position. right or left.
#' @param title Title of the plot.
#' @param legend.position Position of legend. 'none', 'right', 'left' or two numeric variables.
#' @param theme.plot ggtheme of plot.
#' @param use.Chinese Logical. Whether to use Chinese annotation in the barplot.
#' @param appid User app id from baidu translation api. https://fanyi-api.baidu.com/manage/developer.
#' @param key User Key from baidu translation api. https://fanyi-api.baidu.com/manage/developer.
#' @import clusterProfiler
#' @export
#' @examples
#' library(airway)
#' library(DESeq2)
#' library(tidyverse)
#' library(clusterProfiler)
#' library(org.Hs.eg.db)
#' data(airway)
#' se <- airway
#' se$dex <- relevel(se$dex, "untrt")
#' res <- DESeqDataSet(se, design = ~ cell + dex) %>%
#'   estimateSizeFactors() %>%
#'   DESeq() %>%
#'   results() %>%
#'   as.data.frame() %>%
#'   na.omit()
#' ann <- bitr(rownames(res), "ENSEMBL", "SYMBOL", org.Hs.eg.db)
#' res <- merge(ann, res, by.x = 1, by.y = 0) %>% dplyr::distinct(SYMBOL, .keep_all = TRUE)
#'
#' # Obtain an order ranked geneList.
#' grlist <- res$log2FoldChange
#' names(grlist) <- res$SYMBOL
#' grlist <- sort(grlist, decreasing = TRUE)
#'
#' # Integrative enrichment analysis of the ranked gene list
#' fit <- lzq_GSEA.integrated(genes = grlist)
#'
#' lzq_GSEA.dotplot1(enrich.obj = fit$simplyGO, type = "pos")
lzq_GSEA.dotplot1 <- function(
    enrich.obj,
    type = "neg",
    show.term.num = 15,
    Selct.P = "FDR",
    cutoff.P = 0.05,
    colors = c(
      "#003c30", "#01665e", "#35978f", "#80cdc1", "#c7eae5", "#f5f5f5",
      "#f6e8c3", "#dfc27d", "#bf812d", "#8c510a", "#543005"
    ),
    size.range = c(3, 8),
    y.label.position = "right",
    title = NULL,
    legend.position = "right",
    theme.plot = theme_bw(base_rect_size = 1.5),
    use.Chinese = F,
    appid = "20231122001888718",
    key = "5GpDqe8F3pmXfnOkEKGQ") {
  if (Selct.P == "BP") {
    if (type %in% c("Positive", "positive", "pos", "p", "po", "P", "Po", "Pos")) {
      r <- enrich.obj@result %>%
        dplyr::filter(pvalue < cutoff.P, NES > 0) %>%
        dplyr::mutate(sig = -log10(pvalue)) %>%
        dplyr::arrange(dplyr::desc(sig))
    } else {
      r <- enrich.obj@result %>%
        dplyr::filter(pvalue < cutoff.P, NES < 0) %>%
        dplyr::mutate(sig = -log10(pvalue)) %>%
        dplyr::arrange(dplyr::desc(sig))
    }
    x.lab <- bquote(~ -Log[10] ~ italic("P-value"))
  }

  if (Selct.P == "FDR") {
    if (type %in% c("Positive", "positive", "pos", "p", "po", "P", "Po", "Pos")) {
      r <- enrich.obj@result %>%
        dplyr::filter(p.adjust < cutoff.P, NES > 0) %>%
        dplyr::mutate(sig = -log10(p.adjust)) %>%
        dplyr::arrange(dplyr::desc(sig))
    } else {
      r <- enrich.obj@result %>%
        dplyr::filter(p.adjust < cutoff.P, NES < 0) %>%
        dplyr::mutate(sig = -log10(p.adjust)) %>%
        dplyr::arrange(dplyr::desc(sig))
    }
    x.lab <- bquote(~ -Log[10] ~ "FDR")
  }

  show.term.num <- ifelse(nrow(r) >= show.term.num, show.term.num, nrow(r))
  if (show.term.num == 0) {
    stop(paste0("No significant ", tolower(type), " term was enriched in enrich.obj!"))
  }
  r <- r[seq_len(show.term.num), ]

  if (use.Chinese) {
    r$Description <- purrr::map_vec(r$Description, ~ lzq_translate(.x, appid = appid, key = key))
    showtext::showtext_auto()
  }

  r %<>% dplyr::mutate(Description = factor(Description, rev(Description)))

  if (!type %in% c("Positive", "positive", "pos", "p", "po", "P", "Po", "Pos")) {
    color.title <- "abs(NES)"
  } else {
    color.title <- "NES"
  }
  ggplot(r, aes(sig, Description, fill = abs(NES), size = abs(NES))) +
    geom_point(shape = 21, color = "black") +
    labs(size = color.title, fill = color.title, x = x.lab, y = NULL, title = title) +
    scale_fill_gradientn(colours = colors) +
    scale_size(range = size.range) +
    scale_y_discrete(
      labels = Hmisc::capitalize,
      position = y.label.position
    ) +
    theme.plot +
    theme(
      axis.text.y = element_text(size = 13, colour = "black"),
      axis.title.y = element_blank(),
      axis.text.x = element_text(size = 10, colour = "black"),
      axis.title.x = element_text(size = 13, colour = "black", face = "bold"),
      plot.title = element_text(size = 14, colour = "black", face = "bold", hjust = 0.5),
      legend.position = legend.position,
      legend.background = element_blank(),
      legend.key = element_blank(),
      legend.title = element_text(size = 13, colour = "black", face = "bold"),
      legend.text = element_text(size = 11, colour = "black")
    ) +
    guides(fill = guide_legend())
}

utils::globalVariables(c("pvalue", "NES", "sig", "Description"))
