#' @title List of enrichment methods
#' @description
#' List of enrichment methods, including GO, KEGG, MKEGG, WikiPathways, Reactome, MsigDB, DO, CGN, DisGeNET, CellMarker, and CMAP.
#'
#' @author Zaoqu Liu; E-mail: liuzaoqu@163.com
#' @export
#' @examples
#' listEnrichMethod()
listEnrichMethod <- function() {
  print(c("GO", "KEGG", "MKEGG", "WikiPathways", "Reactome", "MsigDB", "DO", "CGN", "DisGeNET", "CellMarker", "CMAP"))
}
